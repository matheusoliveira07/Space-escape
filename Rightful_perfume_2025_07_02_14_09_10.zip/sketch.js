let gameState = "start"; // start, play, gameOver
let points = 0;
let timer = 0;
let player;
let obstacles = [];
let gameOverText = "Game Over! Press ENTER to restart";
let obstacleSpeed = 3;
let stars = [];
let maxPlayerSpeed = 7; // New: Maximum horizontal player speed
let playerVerticalSpeed = 5; // New: Vertical player speed
let engineTrail = []; // For spaceship engine effect

function setup() {
  createCanvas(600, 400);
  player = new Player();
  // Gerar estrelas para o fundo
  for (let i = 0; i < 150; i++) { // More stars for better effect
    stars.push(createVector(random(width), random(height), random(1, 3))); // Added z-index for parallax
  }
  frameRate(60);
}

function draw() {
  // Desenho do fundo
  background(0);
  drawStars();

  if (gameState === "start") {
    displayStartScreen();
  } else if (gameState === "play") {
    playGame();
  } else if (gameState === "gameOver") {
    displayGameOver();
  }
}

function drawStars() {
  noStroke();
  for (let i = stars.length - 1; i >= 0; i--) {
    let star = stars[i];
    let speed = map(star.z, 1, 3, 0.5, 2); // Faster stars are larger
    fill(255, 255, 255, map(star.z, 1, 3, 50, 200)); // Brighter stars are larger
    ellipse(star.x, star.y, star.z);

    star.y += speed;
    if (star.y > height) {
      stars.splice(i, 1); // Remove and add new star
      stars.push(createVector(random(width), 0, random(1, 3)));
    }
  }
}

function displayStartScreen() {
  textSize(32);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Space Escape", width / 2, height / 2 - 80);

  textSize(18);
  text("Evite os asteroides e sobreviva o máximo possível!", width / 2, height / 2);
  text("Pressione ENTER para começar", width / 2, height / 2 + 40);
  text("Use as setas para mover a nave (↑ ↓ ← →)", width / 2, height / 2 + 80);
}

function playGame() {
  timer++;

  // Movimento do jogador
  player.update();
  player.show();

  // Spawn de obstáculos
  if (frameCount % 60 === 0) {
    let obs = new Obstacle();
    obstacles.push(obs);
  }

  // Mover e exibir obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    // Verificar colisão com o jogador
    if (obstacles[i].hits(player)) {
      gameState = "gameOver";
    }

    // Remover obstáculos fora da tela
    if (obstacles[i].offScreen()) {
      obstacles.splice(i, 1);
      points++;
    }
  }

  // Aumentar dificuldade ao longo do tempo
  if (timer % 300 === 0) {
    obstacleSpeed += 0.5;
    // Cap obstacle speed to avoid unplayable difficulty
    obstacleSpeed = min(obstacleSpeed, 10);
  }

  // Exibir pontos e tempo
  displayHUD();
}

function displayHUD() {
  fill(255);
  textSize(18);
  textAlign(LEFT, TOP);
  text("Pontos: " + points, 10, 10);
  text("Tempo: " + Math.floor(timer / 60), 10, 30);
}

function displayGameOver() {
  textSize(32);
  fill(255, 0, 0);
  textAlign(CENTER, CENTER);
  text(gameOverText, width / 2, height / 2 - 40);
  textSize(24); // Slightly larger score display
  fill(255);
  text("Sua Pontuação: " + points, width / 2, height / 2);
  textSize(16);
  text("Pressione ENTER para reiniciar", width / 2, height / 2 + 40);
}

function keyPressed() {
  if (keyCode === ENTER) {
    if (gameState === "start" || gameState === "gameOver") {
      gameState = "play";
      points = 0;
      timer = 0;
      obstacles = [];
      player = new Player(); // Reset player position
      obstacleSpeed = 3; // Reset obstacle speed
      engineTrail = []; // Clear engine trail
    }
  }
}

// Player class (Spaceship)
class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 100; // Starting position higher
    this.size = 50; // Larger size for better visual
    this.velocityX = 0;
    this.velocityY = 0;
    this.color = color(0, 150, 255); // Blue spaceship
    this.tiltAngle = 0; // Inclinação da nave
  }

  update() {
    // Horizontal movement
    if (keyIsDown(LEFT_ARROW)) {
      this.velocityX = -maxPlayerSpeed;
      this.tiltAngle = -PI / 10; // Inclina para a esquerda
    } else if (keyIsDown(RIGHT_ARROW)) {
      this.velocityX = maxPlayerSpeed;
      this.tiltAngle = PI / 10; // Inclina para a direita
    } else {
      this.velocityX = 0;
      this.tiltAngle = 0; // Volta a posição normal
    }

    // Vertical movement
    if (keyIsDown(UP_ARROW)) {
      this.velocityY = -playerVerticalSpeed;
    } else if (keyIsDown(DOWN_ARROW)) {
      this.velocityY = playerVerticalSpeed;
    } else {
      this.velocityY = 0;
    }

    this.x += this.velocityX;
    this.y += this.velocityY;

    // Limitar a posição do jogador dentro da tela
    this.x = constrain(this.x, this.size / 2, width - this.size / 2);
    this.y = constrain(this.y, this.size / 2, height - this.size / 2);

    // Add engine trail particles
    if (this.velocityX !== 0 || this.velocityY !== 0) { // Only add trail when moving
      engineTrail.push(createVector(this.x, this.y + this.size / 2, random(5, 15))); // x, y, size
    }

    // Remove old trail particles
    for (let i = engineTrail.length - 1; i >= 0; i--) {
      engineTrail[i].y += 2; // Drift downwards slightly
      engineTrail[i].x += random(-1, 1); // Slight horizontal drift
      engineTrail[i].z *= 0.95; // Shrink
      if (engineTrail[i].z < 1) {
        engineTrail.splice(i, 1);
      }
    }
  }

  show() {
    push();
    translate(this.x, this.y);
    rotate(this.tiltAngle);

    // Desenha o corpo da nave (more spaceship-like)
    fill(this.color);
    noStroke();
    beginShape();
    vertex(0, -this.size / 2); // Top point
    vertex(this.size / 3, -this.size / 4); // Top right fin
    vertex(this.size / 2, this.size / 4); // Bottom right fin
    vertex(this.size / 4, this.size / 2); // Right engine point
    vertex(-this.size / 4, this.size / 2); // Left engine point
    vertex(-this.size / 2, this.size / 4); // Bottom left fin
    vertex(-this.size / 3, -this.size / 4); // Top left fin
    endShape(CLOSE);

    // Desenha o cockpit
    fill(100, 200, 255, 150); // Lighter blue, semi-transparent
    ellipse(0, -this.size / 4, this.size / 3, this.size / 4);

    // Desenha as luzes da nave (engine glow)
    fill(255, 150, 0, 200); // Orange glow
    ellipse(this.size / 4, this.size / 2.5, this.size / 5); // Right engine
    ellipse(-this.size / 4, this.size / 2.5, this.size / 5); // Left engine

    pop();

    // Draw engine trail
    for (let p of engineTrail) {
      fill(255, random(100, 200), 0, map(p.z, 1, 15, 0, 255)); // Fading orange particles
      ellipse(p.x, p.y, p.z);
    }
  }
}

// Classe do obstáculo (Asteroides)
class Obstacle {
  constructor() {
    this.x = random(width);
    this.y = -50; // Start higher to give more space
    this.size = random(40, 80); // Larger potential size
    this.speed = obstacleSpeed * random(0.8, 1.2); // Vary speed slightly for each asteroid
    this.color = color(random(100, 200), random(50, 150), random(0, 100)); // More muted rock colors
    this.rotation = random(TWO_PI);
    this.rotationSpeed = random(0.01, 0.05);
    // New: Shape variations for asteroids
    this.numVertices = floor(random(5, 9)); // 5 to 8 sided asteroids
    this.vertexOffsets = [];
    for (let i = 0; i < this.numVertices; i++) {
      this.vertexOffsets.push(random(-10, 10)); // Irregularities
    }
  }

  update() {
    this.y += this.speed;
    this.rotation += this.rotationSpeed;
  }

  show() {
    push();
    translate(this.x, this.y);
    rotate(this.rotation);
    fill(this.color);
    noStroke();

    // Desenha o asteroide com um formato irregular (polígono)
    beginShape();
    for (let i = 0; i < this.numVertices; i++) {
      let angle = map(i, 0, this.numVertices, 0, TWO_PI);
      let rad = this.size / 2 + this.vertexOffsets[i]; // Use individual offsets
      let x = rad * cos(angle);
      let y = rad * sin(angle);
      vertex(x, y);
    }
    endShape(CLOSE);
    pop();
  }

  offScreen() {
    return this.y > height + this.size; // Check further down
  }

  hits(player) {
    // Basic circular collision for simplicity, can be improved with more precise shape collision
    let distance = dist(this.x, this.y, player.x, player.y);
    return distance < this.size / 2 + player.size / 2;
  }
}